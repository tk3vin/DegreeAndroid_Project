package com.example.kevin.a202sgi;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper{

    DbBitmapUtility utility;

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "UserManager.db";

    // User table name
    private static final String TABLE_USER = "user";
    private static final String TABLE_CATEGORY = "category";
    private static final String TABLE_ROOM = "product";
    private static final String TABLE_CHECKOUT = "cart";

    // User Table Columns names
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_NAME = "user_name";
    private static final String COLUMN_USER_EMAIL = "user_email";
    private static final String COLUMN_USER_PASSWORD = "user_password";
    private static final String COLUMN_USER_PROFILE_IMAGE = "user_profile_image";
    private static final String COLUMN_USER_PHONE_NUMBER = "user_phone_number";

    private static final String COLUMN_CATEGORY_ID = "category_id";
    private static final String COLUMN_CATEGORY_NAME = "category_name";
    private static final String COLUMN_CATEGORY_IMAGE = "category_image";
    private static final String ITEM_INDEX = "item_index";

    private static final String COLUMN_ROOM_ID = "product_id";
    private static final String COLUMN_ROOM_NAME = "product_name";
    private static final String COLUMN_ROOM_DES = "product_description";
    private static final String COLUMN_ROOM_TYPE = "product_type";
    private static final String COLUMN_ROOM_IMAGE = "product_image";
    private static final String COLUMN_ROOM_PRICE = "product_price";

    private static final String COLUMN_QUANTITY = "product_quantity";
    private static final String COLUMN_CHECKOUT = "checkout";
    private static final String COLUMN_CHECKOUT_ID = "checkout_id";

    // create table sql query
    private String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USER + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USER_NAME + " TEXT,"
            + COLUMN_USER_EMAIL + " TEXT,"
            + COLUMN_USER_PASSWORD + " TEXT,"
            + COLUMN_USER_PROFILE_IMAGE + " BLOB,"
            + COLUMN_USER_PHONE_NUMBER + " INTEGER" + ")";

    private String CREATE_CATEGORY_TABLE = "CREATE TABLE " + TABLE_CATEGORY + "("
            + COLUMN_CATEGORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_CATEGORY_NAME + " TEXT,"
            + COLUMN_CATEGORY_IMAGE + " BLOB,"
            + ITEM_INDEX + "INTEGER" + ")";

    private String CREATE_ROOM_TABLE = "CREATE TABLE " + TABLE_ROOM + "("
            + COLUMN_ROOM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_ROOM_NAME + " TEXT,"
            + COLUMN_ROOM_DES + " TEXT,"
            + COLUMN_ROOM_TYPE + " TEXT,"
            + COLUMN_ROOM_IMAGE + " BLOB,"
            + COLUMN_ROOM_PRICE + " DOUBLE" + ")";

    private String CREATE_CART_TABLE = "CREATE TABLE " + TABLE_CHECKOUT + "("
            + COLUMN_USER_ID + " INTEGER,"
            + COLUMN_ROOM_ID + " INTEGER,"
            + COLUMN_CHECKOUT_ID + " INTEGER,"
            + COLUMN_CHECKOUT + "INTEGER" + ")";

    // drop table sql query
    private String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + TABLE_USER;
    private String DROP_CATEGORY_TABLE = "DROP TABLE IF EXISTS " + TABLE_CATEGORY;
    private String DROP_ROOM_TABLE = "DROP TABLE IF EXISTS " + TABLE_ROOM;
    private String DROP_CART_TABLE = "DROP TABLE IF EXISTS " + TABLE_CHECKOUT;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        db.execSQL(CREATE_CATEGORY_TABLE);
        db.execSQL(CREATE_ROOM_TABLE);
        db.execSQL(CREATE_CART_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //Drop Table if exist
        db.execSQL(DROP_USER_TABLE);
        db.execSQL(DROP_CATEGORY_TABLE);
        db.execSQL(DROP_ROOM_TABLE);
        db.execSQL(DROP_CART_TABLE);

        // Create tables again
        onCreate(db);
    }

    public void addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, user.getName());
        values.put(COLUMN_USER_EMAIL, user.getEmail());
        values.put(COLUMN_USER_PASSWORD, user.getPassword());
        //values.put(COLUMN_USER_PROFILE_IMAGE, utility.getBytes(user.getProfileImage()));
        values.put(COLUMN_USER_PHONE_NUMBER, user.getPhoneNumber());

        // Inserting Row
        db.insert(TABLE_USER, null, values);
        db.close();
    }

    public void addCategory(Hotel cat){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_CATEGORY_NAME, cat.getName());
//        values.put(COLUMN_CATEGORY_IMAGE, cat.getImageResource());

        //Inserting Row
        db.insert(TABLE_CATEGORY, null, values);
        db.close();
    }

    public void addRoom(Room p){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_ROOM_NAME, p.getRoom_name());
        values.put(COLUMN_ROOM_DES, p.getRoom_des());
        values.put(COLUMN_ROOM_TYPE, p.getRoom_type());
        //values.put(COLUMN_ROOM_IMAGE, utility.getBytes(p.getRoom_image()));
        values.put(COLUMN_ROOM_PRICE, p.getRoom_price());

        //Inserting Row
        db.insert(TABLE_ROOM, null, values);
        db.close();
    }

    public void addCheckout(ArrayList<Checkout> checkoutList){
        SQLiteDatabase db = this.getWritableDatabase();

        for (int i = 0; i< checkoutList.size(); i++){
            ContentValues values = new ContentValues();
            values.put(COLUMN_USER_ID, checkoutList.get(i).getUserId());
            values.put(COLUMN_ROOM_ID, checkoutList.get(i).getRoomId());
            values.put(COLUMN_CHECKOUT, 1);
            values.put(COLUMN_CHECKOUT_ID, getCheckoutId(checkoutList.get(i).getUserId()));

            //Inserting Row
            db.update(TABLE_CHECKOUT, values, COLUMN_ROOM_ID + " =? AND" + COLUMN_CHECKOUT + " =? AND" + COLUMN_USER_ID + " =?",
                    new String[]{Integer.toString(checkoutList.get(i).getRoomId()), Integer.toString(0), Integer.toString(checkoutList.get(i).getUserId())});
        }
        db.close();
    }

    public void addtoCheckout(Checkout checkout){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, checkout.getUserId());
        values.put(COLUMN_ROOM_ID, checkout.getRoomId());
        values.put(COLUMN_CHECKOUT, checkout.getCheckout());
        values.put(COLUMN_CHECKOUT_ID, checkout.getCheckoutId());

        //Inserting Row
        db.insert(TABLE_CHECKOUT, null, values);
        db.close();
    }

    public List<User> getAllUser() {
        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_USER_EMAIL,
                COLUMN_USER_NAME,
                COLUMN_USER_PASSWORD,
                COLUMN_USER_PROFILE_IMAGE,
                COLUMN_USER_PHONE_NUMBER
        };
        // sorting orders
        String sortOrder =
                COLUMN_USER_NAME + " ASC";
        List<User> userList = new ArrayList<User>();

        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
                user.setName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_NAME)));
                user.setEmail(cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD)));
                if (cursor.getBlob(cursor.getColumnIndex(COLUMN_USER_PROFILE_IMAGE)) != null){
                    user.setProfileImage(utility.getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_USER_PROFILE_IMAGE))));
                }
                if (cursor.getString(cursor.getColumnIndex(COLUMN_USER_PHONE_NUMBER)) != null) {
                    user.setPhoneNumber(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PHONE_NUMBER)));
                }
                // Adding user record to list
                userList.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return userList;
    }

    public List<Hotel> getAllCategory() {
        // array of columns to fetch
        String[] columns = {
                COLUMN_CATEGORY_ID,
                COLUMN_CATEGORY_NAME,
                COLUMN_CATEGORY_IMAGE,
        };

        List<Hotel> catList = new ArrayList<Hotel>();

        SQLiteDatabase db = this.getReadableDatabase();

        // query the category table
        Cursor cursor = db.query(TABLE_CATEGORY, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Hotel cat = new Hotel();
                cat.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_CATEGORY_ID))));
                cat.setName(cursor.getString(cursor.getColumnIndex(COLUMN_CATEGORY_NAME)));
                //cat.setImageResource(utility.getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_CATEGORY_IMAGE))));
                // Adding category record to list
                catList.add(cat);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return catList;
    }

    public List<Room> getAllRoom(String name) {
        // array of columns to fetch
        String[] columns = {
                COLUMN_ROOM_ID,
                COLUMN_ROOM_NAME,
                COLUMN_ROOM_DES,
                COLUMN_ROOM_TYPE,
                COLUMN_ROOM_IMAGE,
                COLUMN_ROOM_PRICE
        };
        List<Room> roomList = new ArrayList<Room>();

        SQLiteDatabase db = this.getReadableDatabase();

        String selection = COLUMN_ROOM_TYPE + " =?";

        String[] selectionArgs = {name};

        // query the category table
        Cursor cursor = db.query(TABLE_ROOM, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Room p = new Room();
                p.setRoom_id(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_ROOM_ID))));
                p.setRoom_name(cursor.getString(cursor.getColumnIndex(COLUMN_ROOM_NAME)));
                p.setRoom_des(cursor.getString(cursor.getColumnIndex(COLUMN_ROOM_DES)));
                p.setRoom_type(cursor.getString(cursor.getColumnIndex(COLUMN_ROOM_TYPE)));
                //p.setRoom_image(utility.getImage(cursor.getBlob(cursor.getColumnIndex(COLUMN_ROOM_IMAGE))));
                p.setRoom_price(Double.parseDouble(cursor.getString(cursor.getColumnIndex(COLUMN_ROOM_PRICE))));
                // Adding room record to list
                roomList.add(p);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return room list
        return roomList;
    }

    public List<Checkout> getAllCheckout(int userId){
        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID,
                COLUMN_ROOM_ID,
                COLUMN_CHECKOUT_ID,
        };
        List<Checkout> checkoutList = new ArrayList<Checkout>();

        SQLiteDatabase db = this.getReadableDatabase();

        String selection = COLUMN_USER_ID + " =? AND" + COLUMN_CHECKOUT + " ?";

        String[] selectionArgs = {Integer.toString(userId), Integer.toString(0) };

        // query the category table
        Cursor cursor = db.query(TABLE_CHECKOUT, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Checkout c = new Checkout();
                c.setUserId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
                c.setRoomId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_ROOM_ID))));
                c.setCheckoutId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_CHECKOUT_ID))));
                // Adding room record to list
                checkoutList.add(c);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        return checkoutList;
    }

    public void updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_PASSWORD, user.getPassword());

        // updating row
        db.update(TABLE_USER, values, COLUMN_USER_ID + " = ?",
                new String[]{Integer.toString(user.getId())});
        db.close();
    }


    public void updateCategory(Hotel cat) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_CATEGORY_NAME, cat.getName());
//        values.put(COLUMN_CATEGORY_IMAGE, utility.getBytes(cat.getImageResource()));

        // updating row
        db.update(TABLE_CATEGORY, values, COLUMN_CATEGORY_ID + " = ?",
                new String[]{String.valueOf(cat.getId())});
        db.close();
    }

    public void deleteUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        // delete user record by id
        db.delete(TABLE_USER, COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(user.getId())});
        db.close();
    }


    public void deleteCategory(Hotel cat) {
        try{
            SQLiteDatabase db = this.getWritableDatabase();
            // delete category record
            db.delete(TABLE_CATEGORY, COLUMN_CATEGORY_ID + " = ?", new String[]{String.valueOf(cat.getId())});
            db.close();
        }catch(SQLException e){

        }
    }

    public void deleteRoom(Room p) {
        try{
            SQLiteDatabase db = this.getWritableDatabase();
            // delete category record
            db.delete(TABLE_ROOM, COLUMN_ROOM_ID + " = ?", new String[]{String.valueOf(p.getRoom_id())});
            db.close();
        }catch(SQLException e){

        }
    }

    public void deleteAllRooms(String name) {
        try{
            SQLiteDatabase db = this.getWritableDatabase();
            //delete all room records vary by category
            db.delete(TABLE_ROOM, COLUMN_ROOM_TYPE + " =?", new String[] {name});
            db.close();
        }catch(SQLException e){

        }
    }

    public void deleteCart(Checkout c){
        try{
            SQLiteDatabase db = this.getWritableDatabase();
            // delete category record
            db.delete(TABLE_CHECKOUT, COLUMN_ROOM_ID + " = ?", new String[]{String.valueOf(c.getRoomId())});
            db.close();
        }catch(SQLException e){

        }
    }

    public boolean checkUser(String email) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?";

        // selection argument
        String[] selectionArgs = {email};

        // query user table with condition
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public boolean checkCategory(String name) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_CATEGORY_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_CATEGORY_NAME + " = ?";

        // selection argument
        String[] selectionArgs = {name};

        // query user table with condition
        Cursor cursor = db.query(TABLE_CATEGORY, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public boolean checkRoom(String name) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_ROOM_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_ROOM_NAME + " = ?";

        // selection argument
        String[] selectionArgs = {name};

        // query user table with condition
        Cursor cursor = db.query(TABLE_ROOM, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public boolean checkUser(String email, String password) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?" + " AND " + COLUMN_USER_PASSWORD + " = ?";

        // selection arguments
        String[] selectionArgs = {email, password};

        // query user table with conditions
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);                      //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public String getUsername(String email){
        User name = new User();
        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_NAME
        };

        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?";

        // selection arguments
        String[] selectionArgs = {email};

        // query the user table
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order

        if(cursor.moveToFirst()) {
            do {
                name.setName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_NAME)));
            }while(cursor.moveToNext());
        }
        cursor.close();
        return name.getName();
    }

    public int getUserId(String email){
        User name = new User();
        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };

        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?";

        // selection arguments
        String[] selectionArgs = {email};

        // query the user table
        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order

        if(cursor.moveToFirst()) {
            do {
                name.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID)));
            }while(cursor.moveToNext());
        }
        cursor.close();
        return name.getId();
    }

    public int getCheckoutId(int userId) {
        Checkout checkout = new Checkout();
        // array of columns to fetch
        String[] columns = {
                COLUMN_CHECKOUT_ID
        };

        SQLiteDatabase db = this.getReadableDatabase();

        String sortOrder =
                COLUMN_CHECKOUT_ID + " DESC";

        String selection = COLUMN_USER_ID + " = ? AND" + COLUMN_CHECKOUT + " =?";

        String[] selectionArgs = {Integer.toString(userId), Integer.toString(0)};
        // query the user table
        Cursor cursor = db.query(TABLE_CHECKOUT, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order

        if(cursor.moveToFirst()) {
            checkout.setCheckoutId(cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID)));
        }
        cursor.close();
        return checkout.getCheckoutId();
    }

    public Room getRoomDetails(int roomId){
        Room p = new Room();
        // array of columns to fetch
        String[] columns = {
                COLUMN_ROOM_ID,
                COLUMN_ROOM_NAME,
                COLUMN_ROOM_DES,
                COLUMN_ROOM_PRICE
        };

        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_ROOM_ID + " = ?";

        // selection arguments
        String[] selectionArgs = {Integer.toString(roomId)};

        // query the user table
        Cursor cursor = db.query(TABLE_ROOM, //Table to query
                columns,    //columns to return
                selection,        //columns for the WHERE clause
                selectionArgs,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                null); //The sort order

        if(cursor.moveToFirst()) {
            do {
                p.setRoom_id(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_ROOM_ID))));
                p.setRoom_name(cursor.getString(cursor.getColumnIndex(COLUMN_ROOM_NAME)));
                p.setRoom_des(cursor.getString(cursor.getColumnIndex(COLUMN_ROOM_DES)));
                p.setRoom_type(cursor.getString(cursor.getColumnIndex(COLUMN_ROOM_TYPE)));
                p.setRoom_price(Double.parseDouble(cursor.getString(cursor.getColumnIndex(COLUMN_ROOM_PRICE))));
            }while(cursor.moveToNext());
        }
        cursor.close();
        return p;
    }
}

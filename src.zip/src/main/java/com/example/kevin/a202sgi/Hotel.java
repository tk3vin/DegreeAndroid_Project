package com.example.kevin.a202sgi;

public class Hotel {
    private int id;
    private String name;
//    private Bitmap imageResource;

    public Hotel(){
        this.id = 0;
        this.name = "";
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

//    public Bitmap getImageResource() {
//        return imageResource;
//    }
//
//    public void setImageResource(Bitmap im) {
//        this.imageResource = im;
//    }
}
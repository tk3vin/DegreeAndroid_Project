package com.example.kevin.a202sgi;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

class RoomAdapter extends RecyclerView.Adapter<RoomAdapter.ViewHolder>{

    private ArrayList<Room> listRoom;
    private Context mContext;
    DatabaseHelper databaseHelper;
    SessionManager session;
    private Checkout checkout;
    String email;

    public RoomAdapter(Context context, ArrayList<Room> listRoom) {
        this.listRoom = listRoom;
        this.mContext = context;
    }

    @Override
    public RoomAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.room_list, parent, false);

        // inflating recycler item view
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RoomAdapter.ViewHolder holder, int position) {

        //Get current category
        final Room currentRoom = listRoom.get(position);
        session = new SessionManager(mContext);
        HashMap<String, String> user = session.getUserDetails();
        email = user.get(SessionManager.KEY_EMAIL);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //add to checkout function
                Intent i = new Intent(mContext, CheckoutActivity.class);
                checkout.setUserId(databaseHelper.getUserId(email));
                checkout.setRoomId(currentRoom.getRoom_id());
                checkout.setCheckout(0);
                checkout.setCheckoutId(databaseHelper.getCheckoutId(databaseHelper.getUserId(email)));
                databaseHelper.addtoCheckout(checkout);
                mContext.startActivity(i);

            }
        });

        //Populate the text views with data
        holder.bindTo(currentRoom);
    }

    @Override
    public int getItemCount() {
        Log.v(RoomAdapter.class.getSimpleName(),"showing list" + listRoom.size());
        return listRoom.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView textViewRoomId;
        public TextView textViewRoomName;
        public TextView textViewRoomDescription;
        public TextView textViewRoomPrice;
        public ImageView imageView;

        public ViewHolder(View view) {
            super(view);
            textViewRoomId = (TextView) view.findViewById(R.id.textViewRoomId);
            textViewRoomName = (TextView) view.findViewById(R.id.textViewRoomName);
            textViewRoomDescription = (TextView) view.findViewById(R.id.textViewRoomDescription);
            textViewRoomPrice = (TextView) view.findViewById(R.id.textViewRoomPrice);
            imageView = (ImageView) view.findViewById(R.id.iv_hotel);
        }

        public void bindTo(Room currentRoom) {
            //Populate the text views with data
            textViewRoomId.setText("R 000" + Integer.toString(currentRoom.getRoom_id()));
            textViewRoomName.setText(currentRoom.getRoom_name());
            textViewRoomDescription.setText(currentRoom.getRoom_des());
            textViewRoomPrice.setText("RM " + Double.toString(currentRoom.getRoom_price()));
            //Glide.with(mContext).load(currentCat.getImageResource()).into(imageView);
        }
    }
}


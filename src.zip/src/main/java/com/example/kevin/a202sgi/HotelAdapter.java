package com.example.kevin.a202sgi;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

class HotelAdapter extends RecyclerView.Adapter<HotelAdapter.ViewHolder>{

    private ArrayList<Hotel> listHotel;
    private Context mContext;
    SessionManager session;
    String name;

    public HotelAdapter(Context context, ArrayList<Hotel> listHotel) {
        this.listHotel = listHotel;
        this.mContext = context;
    }

    @Override
    public HotelAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.list_item, parent, false);

        // inflating recycler item view
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(HotelAdapter.ViewHolder holder, int position){
        //Get current category
        final Hotel currentCat = listHotel.get(position);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(mContext, RoomActivity.class);
                i.putExtra("category_name", currentCat.getName());
                mContext.startActivity(i);
            }
        });

        //Populate the text views with data
        holder.bindTo(currentCat);
    }

    @Override
    public int getItemCount() {
        Log.v(HotelAdapter.class.getSimpleName(),"showing list"+ listHotel.size());
        return listHotel.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView mTextView;
        public ImageView mImageView;

        public ViewHolder(View view) {
            super(view);
            mTextView = (TextView) view.findViewById(R.id.title);
            mImageView = (ImageView) view.findViewById(R.id.iv_hotel);
        }

        public void bindTo(Hotel currentCat) {
            //Populate the text views with data
            mTextView.setText(currentCat.getName());
            //Glide.with(mContext).load(currentCat.getImageResource()).into(mImageView);
        }
    }
}


package com.example.kevin.a202sgi;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class RoomActivity extends AppCompatActivity {

    //Member variables
    private AppCompatActivity activity = RoomActivity.this;
    private RecyclerView recyclerViewRoom;
    private ArrayList<Room> listRoom;
    private RoomAdapter roomAdapter;
    private DatabaseHelper databaseHelper;
    private Button button;
    SessionManager session;
    String sessionName;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // Session class instance
        session = new SessionManager(getApplicationContext());
        button = (Button) findViewById(R.id.addRoom);
        initViews();
        initObjects();
        HashMap<String, String> user = session.getUserDetails();
        sessionName = user.get(SessionManager.KEY_NAME);

        if (sessionName.equals("admin")){
            enableSwipeToDeleteAndUndo();
            button.setVisibility(View.VISIBLE);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(RoomActivity.this, AddRoom.class);
                    i.putExtra("category_name", name);
                    startActivity(i);
                }
            });
        }else{
            button.setVisibility(View.GONE);
        }
    }

    private void initViews() {
        recyclerViewRoom = (RecyclerView) findViewById(R.id.roomRecyclerView);
    }

    private void initObjects() {
        //Initialize ArrayList
        listRoom = new ArrayList<>();

        //Pass context and ArrayList to Adapter
        roomAdapter = new RoomAdapter(this, listRoom);

        //Set Layout Manager
        recyclerViewRoom.setLayoutManager(new LinearLayoutManager(this));

        //Initialize Adapter and set on Recycler View
        recyclerViewRoom.setAdapter(roomAdapter);

        //Initialize Database Helper
        databaseHelper = new DatabaseHelper(activity);

        Bundle b = getIntent().getExtras();
        if (b != null)
        {
            name = (b.getString("category_name"));
        }

        getDataFromSQLite();
    }

    private void enableSwipeToDeleteAndUndo() {
        SwipeToDeleteCallback swipeToDeleteCallback = new SwipeToDeleteCallback(this) {
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                final int position = viewHolder.getAdapterPosition();
                final Room item = getData().get(position);

                removeItem(position, item);

                Toast.makeText(RoomActivity.this, "Room is deleted from the list!", Toast.LENGTH_SHORT).show();
            }

            private void removeItem(int position, Room item) {
                listRoom.remove(position);
                roomAdapter.notifyItemRemoved(position);
                databaseHelper.deleteRoom(item);
//                Intent intent = new Intent(getApplicationContext(), AdminAddCategory.class);
//                startActivity(intent);
            }

            public ArrayList<Room> getData() {
                return listRoom;
            }
        };

        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeToDeleteCallback);
        itemTouchhelper.attachToRecyclerView(recyclerViewRoom);
    }

    private void getDataFromSQLite() {
        // AsyncTask is used that SQLite operation not blocks the UI Thread.
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                listRoom.clear();
                listRoom.addAll(databaseHelper.getAllRoom(name));
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                roomAdapter.notifyDataSetChanged();
            }
        }.execute();
    }
}

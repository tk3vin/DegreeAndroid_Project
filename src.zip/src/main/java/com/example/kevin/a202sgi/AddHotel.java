package com.example.kevin.a202sgi;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatImageView;
import android.view.View;

public class AddHotel extends AppCompatActivity implements View.OnClickListener {

    private static final int RESULT_LOAD_IMAGE = 1;
    private final AppCompatActivity activity = AddHotel.this;
    private NestedScrollView nestedScrollView;
    private TextInputLayout textInputLayoutName;
    private TextInputLayout textInputLayoutImage;
    private AppCompatButton appCompatButtonAdd;
    private AppCompatButton appCompatButtonUpload;
    private TextInputEditText textInputEditTextName;
    private AppCompatImageView imageToUpload;
    private InputValidation inputValidation;
    private DatabaseHelper databaseHelper;
    private Hotel Hotel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_hotel);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initViews();
        initListeners();
        initObjects();

    }

    private void initViews() {
        nestedScrollView = (NestedScrollView) findViewById(R.id.nestedScrollView);
        textInputLayoutName = (TextInputLayout) findViewById(R.id.hotel_name);
        textInputLayoutImage = (TextInputLayout) findViewById(R.id.hotel_image);
        textInputEditTextName = (TextInputEditText) findViewById(R.id.ti_hotel_name);
        appCompatButtonAdd = (AppCompatButton) findViewById(R.id.btn_addToHotel);
        appCompatButtonUpload = (AppCompatButton) findViewById(R.id.btn_upload_image);
        imageToUpload = (AppCompatImageView) findViewById(R.id.iv_display_upload);
    }

    private void initListeners() {
        appCompatButtonAdd.setOnClickListener(this);
        appCompatButtonUpload.setOnClickListener(this);
    }

    private void initObjects() {
        inputValidation = new InputValidation(activity);
        databaseHelper = new DatabaseHelper(activity);
        Hotel = new Hotel();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_addToHotel:
                postDataToSQLite();
                break;

            case R.id.btn_upload_image:
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, RESULT_LOAD_IMAGE);
                break;
        }

    }

    private void postDataToSQLite() {
        if (!inputValidation.isInputEditTextFilled(textInputEditTextName, textInputLayoutName, getString(R.string.error_message_name))) {
            return;
        }
        else{
            if(!databaseHelper.checkCategory(textInputEditTextName.getText().toString().trim())){
                Hotel.setName(textInputEditTextName.getText().toString().trim());
                databaseHelper.addCategory(Hotel);
                Snackbar.make(nestedScrollView, "Hotel Added to Database", Snackbar.LENGTH_LONG).show();
            }
        }
        emptyInputEditText();
        Intent i = new Intent(this, HotelActivity.class);
        startActivity(i);
    }

    private void emptyInputEditText() {
        textInputEditTextName.setText(null);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && data != null){
            Uri selectedImage = data.getData();
            imageToUpload.setImageURI(selectedImage);
        }
    }
}

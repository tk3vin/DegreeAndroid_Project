package com.example.kevin.a202sgi;

public class Room {
    private int room_id;
    private String room_name;
    private String room_des;
    private String room_type;
//    private Bitmap room_image;
    private Double room_price;

    public int getRoom_id(){
        return room_id;
    }

    public void setRoom_id(int room_id){
        this.room_id = room_id;
    }

    public String getRoom_name(){
        return room_name;
    }

    public void setRoom_name(String room_name){
        this.room_name = room_name;
    }

    public String getRoom_des(){
        return room_des;
    }

    public void setRoom_des(String room_des){
        this.room_des = room_des;
    }

    public String getRoom_type() {return room_type;}

    public void setRoom_type(String room_type) {this.room_type = room_type;}

//    public Bitmap getRoom_image(){
//        return room_image;
//    }
//
//    public void setRoom_image(Bitmap room_image){
//        this.room_image = room_image;
//    }

    public Double getRoom_price(){
        return room_price;
    }

    public void setRoom_price(Double room_price){
        this.room_price = room_price;
    }
}

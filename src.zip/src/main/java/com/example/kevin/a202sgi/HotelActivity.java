package com.example.kevin.a202sgi;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class HotelActivity extends AppCompatActivity {

    //Member variables
    private AppCompatActivity activity = HotelActivity.this;
    private RecyclerView recyclerViewCategory;
    private ArrayList<Hotel> listHotel;
    private HotelAdapter catAdapter;
    private DatabaseHelper databaseHelper;
    private Button button;
    SessionManager session;
    String sessionName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel);
        button = (Button) findViewById(R.id.addHotel);
        session = new SessionManager(getApplicationContext());
        initViews();
        initObjects();
        HashMap<String, String> user = session.getUserDetails();
        sessionName = user.get(SessionManager.KEY_NAME);

        if (sessionName.equals("admin")){
            enableSwipeToDeleteAndUndo();
            button.setVisibility(View.VISIBLE);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(HotelActivity.this, AddHotel.class);
                    startActivity(i);
                }
            });
        }else{
            button.setVisibility(View.INVISIBLE);
        }
    }

    private void initViews() {
        recyclerViewCategory = (RecyclerView) findViewById(R.id.catRecyclerView);
    }

    private void initObjects() {
        //Initialize ArrayList
        listHotel = new ArrayList<>();

        //Pass context and ArrayList to Adapter
        catAdapter = new HotelAdapter(this, listHotel);

        //Set Layout Manager
        recyclerViewCategory.setLayoutManager(new LinearLayoutManager(this));

        //Initialize Adapter and set on Recycler View
        recyclerViewCategory.setAdapter(catAdapter);

        //Initialize Database Helper
        databaseHelper = new DatabaseHelper(activity);

        Hotel category = new Hotel();

        getDataFromSQLite();
    }

    private void enableSwipeToDeleteAndUndo() {
        SwipeToDeleteCallback swipeToDeleteCallback = new SwipeToDeleteCallback(this) {
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                final int position = viewHolder.getAdapterPosition();
                final Hotel item = getData().get(position);

                removeItem(position, item);

                Toast.makeText(HotelActivity.this, "Hotel is deleted from the list!", Toast.LENGTH_SHORT).show();
            }

            private void removeItem(int position, Hotel item) {
                listHotel.remove(position);
                catAdapter.notifyItemRemoved(position);
                databaseHelper.deleteAllRooms(item.getName());
                databaseHelper.deleteCategory(item);
//                Intent intent = new Intent(getApplicationContext(), AdminAddCategory.class);
//                startActivity(intent);
            }

            public ArrayList<Hotel> getData() {
                return listHotel;
            }
        };

        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeToDeleteCallback);
        itemTouchhelper.attachToRecyclerView(recyclerViewCategory);
    }

    private void getDataFromSQLite() {
        // AsyncTask is used that SQLite operation not blocks the UI Thread.
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                listHotel.clear();
                listHotel.addAll(databaseHelper.getAllCategory());

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                catAdapter.notifyDataSetChanged();
            }
        }.execute();
    }
}

package com.example.kevin.a202sgi;

class Checkout {
    private int userId;
    private int roomId;
    private int checkout;
    private int checkoutId;

    public void setUserId(int userId){
        this.userId = userId;
    }

    public int getUserId(){return userId;}

    public void setRoomId(int roomId){
        this.roomId = roomId;
    }

    public int getRoomId(){return roomId;}

    public void setCheckout(int checkout){
        this.checkout = checkout;
    }

    public int getCheckout(){return checkout;}

    public void setCheckoutId(int checkoutId){
        this.checkoutId = checkoutId;
    }

    public int getCheckoutId(){return checkoutId;}
}

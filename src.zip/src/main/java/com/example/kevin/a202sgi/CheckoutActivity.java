package com.example.kevin.a202sgi;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class CheckoutActivity extends AppCompatActivity {

    //Member variables
    private AppCompatActivity activity = CheckoutActivity.this;
    private RecyclerView recyclerViewCart;
    private ArrayList<Room> listRoom;
    private ArrayList<Checkout> listCheckout;
    private CheckoutAdapter checkoutAdapter;
    private DatabaseHelper databaseHelper;
    private Button button;
    private TextView textViewTotalPrice;
    SessionManager session;
    String sessionEmail;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initViews();
        initObjects();
        enableSwipeToDeleteAndUndo();
    }

    private void initViews() {
        recyclerViewCart = (RecyclerView) findViewById(R.id.cartRecyclerView);
        textViewTotalPrice = (TextView) findViewById(R.id.total_price);
    }

    private void initObjects() {
        //Initialize ArrayList
        listCheckout = new ArrayList<>();

        //Pass context and ArrayList to Adapter
        checkoutAdapter = new CheckoutAdapter(this, listCheckout);

        //Set Layout Manager
        recyclerViewCart.setLayoutManager(new LinearLayoutManager(this));

        //Initialize Adapter and set on Recycler View
        recyclerViewCart.setAdapter(checkoutAdapter);

        //Initialize Database Helper
        databaseHelper = new DatabaseHelper(activity);

        //get email from login session
        session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();
        sessionEmail = user.get(SessionManager.KEY_EMAIL);

//        getDataFromSQLite(sessionEmail);
    }

    private void enableSwipeToDeleteAndUndo() {
        SwipeToDeleteCallback swipeToDeleteCallback = new SwipeToDeleteCallback(this) {
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                final int position = viewHolder.getAdapterPosition();
                final Checkout item = getData().get(position);

                removeItem(position, item);

                Toast.makeText(CheckoutActivity.this, "Item is deleted from the list!", Toast.LENGTH_SHORT).show();
            }

            private void removeItem(int position, Checkout item) {
                listCheckout.remove(position);
                checkoutAdapter.notifyItemRemoved(position);
                databaseHelper.deleteCart(item);
//                Intent intent = new Intent(getApplicationContext(), AdminAddCategory.class);
//                startActivity(intent);
            }

            public ArrayList<Checkout> getData() {
                return listCheckout;
            }
        };

        ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeToDeleteCallback);
        itemTouchhelper.attachToRecyclerView(recyclerViewCart);
    }

//    private void getDataFromSQLite(final String sessionEmail) {
//        // AsyncTask is used that SQLite operation not blocks the UI Thread.
//        new AsyncTask<Void, Void, Void>() {
//            @Override
//            protected Void doInBackground(Void... params) {
//                listCheckout.clear();
//                listCheckout.addAll(databaseHelper.getAllCheckout(databaseHelper.getUserId(sessionEmail)));
//                return null;
//            }
//
//            @Override
//            protected void onPostExecute(Void aVoid) {
//                super.onPostExecute(aVoid);
//                checkoutAdapter.notifyDataSetChanged();
//            }
//        }.execute();
//    }

    public void onClick(View view) {
        Intent i = new Intent(this, MainActivity.class);
        databaseHelper.addCheckout(listCheckout);
        startActivity(i);
    }
}

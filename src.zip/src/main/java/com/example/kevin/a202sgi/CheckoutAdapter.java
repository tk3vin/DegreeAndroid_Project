package com.example.kevin.a202sgi;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class CheckoutAdapter extends RecyclerView.Adapter<CheckoutAdapter.ViewHolder>{

    private ArrayList<Checkout> listCheckout;
    private Context mContext;
    DatabaseHelper databaseHelper;
    SessionManager session;
    private Checkout checkout;
    String name;
    String email;

    public CheckoutAdapter(Context context, ArrayList<Checkout> listCheckout) {
        this.listCheckout = listCheckout;
        this.mContext = context;
    }

    @Override
    public CheckoutAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.room_list, parent, false);

        // inflating recycler item view
        return new CheckoutAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CheckoutAdapter.ViewHolder holder, int position) {

        //Get current position
        final Checkout currentCheckout = listCheckout.get(position);
        Room currentRoom = new Room();
        currentRoom = databaseHelper.getRoomDetails(currentCheckout.getRoomId());

        //Populate the text views with data
        holder.bindTo(currentRoom);
    }

    @Override
    public int getItemCount() {
        Log.v(CheckoutAdapter.class.getSimpleName(),"showing list" + listCheckout.size());
        return listCheckout.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView textViewRoomId;
        public TextView textViewRoomName;
        public TextView textViewRoomDescription;
        public TextView textViewRoomPrice;

        public ViewHolder(View view) {
            super(view);
            textViewRoomId = (TextView) view.findViewById(R.id.textViewCheckId);
            textViewRoomName = (TextView) view.findViewById(R.id.textViewCheckName);
            textViewRoomDescription = (TextView) view.findViewById(R.id.textViewCheckDescription);
            textViewRoomPrice = (TextView) view.findViewById(R.id.textViewCheckPrice);
        }

        public void bindTo(Room currentRoom) {
            //Populate the text views with data
            textViewRoomId.setText("P 000" + Integer.toString(currentRoom.getRoom_id()));
            textViewRoomName.setText(currentRoom.getRoom_name());
            textViewRoomDescription.setText(currentRoom.getRoom_des());
            textViewRoomPrice.setText("RM " + Double.toString(currentRoom.getRoom_price()));
            //Glide.with(mContext).load(currentCat.getImageResource()).into(imageView);
        }
    }
}

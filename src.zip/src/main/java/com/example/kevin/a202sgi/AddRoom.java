package com.example.kevin.a202sgi;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatImageView;
import android.view.View;

public class AddRoom extends AppCompatActivity implements View.OnClickListener{

    private static final int RESULT_LOAD_IMAGE = 1;
    private final AppCompatActivity activity = AddRoom.this;
    private NestedScrollView nestedScrollView;

    private TextInputLayout textInputLayoutName;
    private TextInputLayout textInputLayoutImage;
    private TextInputLayout textInputLayoutDes;
    private TextInputLayout textInputLayoutPrice;

    private TextInputEditText textInputEditTextName;
    private TextInputEditText textInputEditTextDes;
    private TextInputEditText textInputEditTextPrice;


    private AppCompatButton appCompatButtonAdd;
    private AppCompatButton appCompatButtonUpload;
    private AppCompatImageView imageToUpload;
    private InputValidation inputValidation;
    private DatabaseHelper databaseHelper;
    private Room room;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_room);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initViews();
        initListeners();
        initObjects();

    }

    private void initViews() {
        nestedScrollView = (NestedScrollView) findViewById(R.id.nestedScrollView1);
        textInputLayoutName = (TextInputLayout) findViewById(R.id.room_name);
        textInputLayoutImage = (TextInputLayout) findViewById(R.id.room_image);
        textInputLayoutDes = (TextInputLayout) findViewById(R.id.room_des);
        textInputLayoutPrice = (TextInputLayout) findViewById(R.id.room_price);
        textInputEditTextName = (TextInputEditText) findViewById(R.id.ti_room_name);
        textInputEditTextDes = (TextInputEditText) findViewById(R.id.ti_room_des);
        textInputEditTextPrice = (TextInputEditText) findViewById(R.id.ti_room_price);
        appCompatButtonAdd = (AppCompatButton) findViewById(R.id.btn_addToRoom);
        appCompatButtonUpload = (AppCompatButton) findViewById(R.id.btn_upload_img);
        imageToUpload = (AppCompatImageView) findViewById(R.id.iv_dis_upload);
    }

    private void initListeners() {
        appCompatButtonAdd.setOnClickListener(this);
        appCompatButtonUpload.setOnClickListener(this);
    }

    private void initObjects() {
        inputValidation = new InputValidation(activity);
        databaseHelper = new DatabaseHelper(activity);
        room = new Room();
        Bundle b = getIntent().getExtras();
        if (b != null)
        {
            name = (b.getString("category_name"));
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_addToRoom:
                postDataToSQLite();
                break;

            case R.id.btn_upload_img:
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, RESULT_LOAD_IMAGE);
                break;
        }

    }

    private void postDataToSQLite() {
        if (!inputValidation.isInputEditTextFilled(textInputEditTextName, textInputLayoutName, getString(R.string.error_message_name))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(textInputEditTextDes, textInputLayoutDes, "Enter the Description")){
            return;
        }
        if (!inputValidation.isInputEditTextFilled(textInputEditTextPrice, textInputLayoutPrice, "Enter the Price")){
            return;
        }
        if(!databaseHelper.checkRoom(textInputEditTextName.getText().toString().trim())){
            room.setRoom_name(textInputEditTextName.getText().toString().trim());
            room.setRoom_des(textInputEditTextDes.getText().toString().trim());
            room.setRoom_type(name);
            room.setRoom_price(Double.parseDouble(textInputEditTextPrice.getText().toString().trim()));
            databaseHelper.addRoom(room);
            Snackbar.make(nestedScrollView, "Room Added to Database", Snackbar.LENGTH_LONG).show();
        }
        emptyInputEditText();
        Intent i = new Intent(this, HotelActivity.class);
        startActivity(i);
    }

    private void emptyInputEditText() {
        textInputEditTextName.setText(null);
        textInputEditTextDes.setText(null);
        textInputEditTextPrice.setText(null);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && data != null){
            Uri selectedImage = data.getData();
            imageToUpload.setImageURI(selectedImage);
        }
    }
}
